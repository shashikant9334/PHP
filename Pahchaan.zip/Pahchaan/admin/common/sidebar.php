<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand" ><span class="fa fa-area-chart"></span> Admin<span class="dashboard_text"> Dashboard</span></a></h1>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header">MAIN NAVIGATION</li>
              <li class="treeview">
                <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
           
               <li class="treeview">
                <a href="all_cat.php">
                <i class="fa fa-laptop"></i> <span>Categories</span>
                </a>
              </li>
              <li class="treeview">
                <a href="donate.php">
                <i class="fa fa-laptop"></i>
                <span>Donation</span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="m_donation.php"><i class="fa fa-angle-right"></i> Money_donation</a></li>
                  <li><a href="donate.php"><i class="fa fa-angle-right"></i> Donations</a></li>
                </ul>
              </li>
              <li class="treeview">
                <a href="m_volunteer.php">
                <i class="fa fa-laptop"></i> <span>Manage volunteer</span>
                </a>
              </li>
              <li class="treeview">
                <a href="m_user.php">
                <i class="fa fa-laptop"></i> <span>Manage User</span>
                </a>
              </li>
              <li class="treeview">
                <a href="m_event.php">
                <i class="fa fa-laptop"></i> <span>view Events</span>
                </a>
              </li>
              <li class="treeview">
                <a href="v_i.php">
                <i class="fa fa-laptop"></i> <span>View Inquiry</span>
                </a>
              </li>
              <li class="treeview">
                <a href="v_feedback.php">
                <i class="fa fa-laptop"></i> <span>View Feed-back</span>
                </a>
              </li>
              <li class="treeview">
                <a href="logout.php">
                <i class="fa fa-sign-out"></i> <span>Logout</span>
                </a>
              </li>
             </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>