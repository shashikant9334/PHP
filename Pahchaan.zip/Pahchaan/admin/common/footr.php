<div class="footer">
	   <p> <a href="../user1/home.php" target="_blank">Helping-Hand(NGO)</a></p>		
	</div>